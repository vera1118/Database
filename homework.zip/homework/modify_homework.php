1<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php session_start(); ?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<body>
<?php
header("content-type:text/html;charset=utf-8");
if(!isset($_POST['submit'])){
    exit('非法访问!');
}
$deadline = $fullmark = $request = $file = $cid = $time =$tid =$sid="";
$deadline= $_POST['deadline'];
$cid=$_POST['cid'];
$time= $_POST['time'];
$tid=$_SESSION['tid']; 

//注册信息判断
if(strlen($deadline)==0){
    exit('错误：截止时间不能为空。<a href="javascript:history.back(-1);">返回</a>');}
if(strlen($cid)==0){
    exit('错误：课程编号不能为空。<a href="javascript:history.back(-1);">返回</a>');}
if(strlen($time)==0){
    exit('错误：次数不能为空。<a href="javascript:history.back(-1);">返回</a>');}




    
$con=mysql_connect("localhost","root","") or die("数据库连接失败");
mysql_query($con,"set names utf8");
mysql_select_db("homework", $con);


$regdate = time();
$sql ="UPDATE homework SET deadline = '$deadline' WHERE cid = '$cid' AND time = '$time'";
if(mysql_query($sql,$con))
{
    header("Location:modify_homework_success.html");
} 
else 
{
    echo '抱歉！添加数据失败：',mysql_error(),'<br />';
    echo '点击此处 <a href="javascript:history.back(-1);">返回</a> 重试';
}
?>
</body>
</html>