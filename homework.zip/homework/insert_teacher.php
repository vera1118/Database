<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php session_start(); ?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<body>
<?php
header("content-type:text/html;charset=utf-8");
if(!isset($_POST['submit'])){
    exit('非法访问!');
}
$tid = $tname = $tpassword = $password_confirm = "";
$tid = $_POST['tid'];
$tname = $_POST['tname'];
$tpassword = $_POST['tpassword'];
$password_confirm = $_POST['password_confirm'];

//注册信息判断
if(strlen($tid)==0){
    exit('错误：学号不能为空。<a href="javascript:history.back(-1);">返回</a>');}
if(strlen($tname)==0){
    exit('错误：姓名不能为空。<a href="javascript:history.back(-1);">返回</a>');}
if(strlen($tpassword) < 6 || strlen($tpassword) > 20){
    exit('错误：密码长度必须在6~20位之间。<a href="javascript:history.back(-1);">返回</a>');}
if($tpassword !=$password_confirm){
    exit('错误：两次输入的密码不一致。<a href="javascript:history.back(-1);">返回</a>');}
    
$con=mysql_connect("localhost","root","") or die("数据库连接失败");
mysql_query($con,"set names utf8");
mysql_select_db("homework", $con);
$check_query = mysql_query("select tid from teacher where tid='$tid'");

if(mysql_fetch_array($check_query))
{
	
    echo '错误：用户名 ',$tid,' 已存在。<a href="javascript:history.back(-1);">返回</a>';
    exit;
}

$regdate = time();
$sql ="INSERT INTO teacher (tid,tname,tpassword)VALUES( '$tid','$tname','$tpassword')";
if(mysql_query($sql,$con))
{
    header("Location:teacher_insert_success.html");
} 
else 
{
    echo '抱歉！添加数据失败：',mysql_error(),'<br />';
    echo '点击此处 <a href="javascript:history.back(-1);">返回</a> 重试';
}
?>
</body>
</html>