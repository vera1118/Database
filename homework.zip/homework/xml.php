<?php 
$conn = mysql_connect('localhost', 'root', '') or die('Could not connect: ' . mysql_error()); 
mysql_select_db('homework', $conn) or die ('Can\'t use database : ' . mysql_error()); 
$str = "SELECT sid,sname,tname,cid,cname FROM `sc` GROUP BY `id` ORDER BY `id` ASC"; 
$result = mysql_query($str) or die("Invalid query: " . mysql_error()); 
if($result) 
{ 
$xmlDoc = new DOMDocument(); 



$xmlstr = "<?xml version='1.0' encoding='utf-8' ?><message></message>"; 
$xmlDoc->loadXML($xmlstr); 
$xmlDoc->save("01.xml");
$xmlDoc->load("01.xml");} 
$Root = $xmlDoc->documentElement; 

while ($arr = mysql_fetch_array($result)){ 
$article = $xmlDoc->createElement('article');
$Root->appendChild($article); 

$node1 = $xmlDoc->createElement("sid"); 
$text = $xmlDoc->createTextNode(iconv("GB2312","UTF-8",$arr["sid"])); 
$node1->appendChild($text); 

$node2 = $xmlDoc->createElement("sname"); 
$text2 = $xmlDoc->createTextNode(iconv("GB2312","UTF-8",$arr["sname"])); 
$node2->appendChild($text2); 

$node3 = $xmlDoc->createElement("cname"); 
$text3 = $xmlDoc->createTextNode(iconv("GB2312","UTF-8",$arr["cname"])); 
$node3->appendChild($text3); 

$node4 = $xmlDoc->createElement("tname"); 
$text4 = $xmlDoc->createTextNode(iconv("GB2312","UTF-8",$arr["tname"])); 
$node4->appendChild($text4); 

$article->appendChild($node1); 
$article->appendChild($node2); 
$article->appendChild($node3);
$article->appendChild($node4);

$xmlDoc->save("01.xml"); 



} 
mysql_close($conn); 
?>