<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php
session_start();
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>有个网站只有我们知道</title>
<style type="text/css"> 
table,td{ 
 border:1px solid #ccc; 
 line-height: 30px;
 border-collapse:collapse; 
 text-align: center;
} 
td{
  width: 100px;
  text-align: center;

}
th{
   border:1px solid #ccc; 
   text-align: center;
   padding-left,padding-right: 100px;
   
   
}
</style>

	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<link href="css/bootstrap-theme.min.css" rel="stylesheet" type="text/css">
	<link href="css/templatemo_style.css" rel="stylesheet" type="text/css">	
    <link href="http://libs.baidu.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet">
   <script src="http://libs.baidu.com/jquery/2.0.0/jquery.min.js"></script>
   <script src="http://libs.baidu.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
</head>

<body class="templatemo-bg-gray">
  <?php
header("content-type:text/html;charset=utf-8");
//连接数据库

$dblink=mysql_connect("localhost","root","") or die("数据库连接失败");

//设置字符串编码

mysql_query("set names utf8");

//选择数据库

mysql_select_db("homework");
if(!$_SESSION['mid'])
{
  header("location:mlogin.html");
}
else
{
  $mid=$_SESSION['mid'];  
  
  
}
?>


<div id="header1" ><img src="images/worksapce_logo.jpg"  alt="" />
</div>
<div  style=" width:80%;text-align:right;" >
<div class="btn btn-default">
  <a href="index.html">退出</a>
  </div>

</div>
<div id="container4">
<div style="width:120px; float:left; background-color:#FFF; padding:0px;"  class="templatemo-container">
<ul id="myTab" class="nav nav-pills  nav-stacked " style="width:100px;"> 

<li class="dropdown">
      <a href="#" id="myTabDrop1" class="dropdown-toggle" 
         data-toggle="dropdown" style="width:120px; ">教师信息<b class="caret"></b>
      </a>
      <ul class="dropdown-menu" role="menu" aria-labelledby="myTabDrop1">
         <li><a href="#add_teacher" tabindex="-1" data-toggle="tab" >
            添加教师信息</a>
         </li>
          <li><a href="#all_teachers" tabindex="-1" data-toggle="tab"  >
            所有教师</a>
         </li>
        
      </ul>
   </li>
   <li  ><a href="#stu_information" data-toggle="tab"style="width:120px;" >学生信息</a></li>
  
   <li><a href="#lessons" data-toggle="tab" style="width:120px; ">课程信息</a></li>
   <li><a href="#stu_lessons" data-toggle="tab" style="width:120px; ">学生选课表</a></li>
   
   
   
   
</ul>
</div>
<div id="myTabContent" class="tab-content">
    <div class="tab-pane fade" id="all_teachers" style=" padding-left:150px;">
      
<?php


$result = mysql_query("SELECT * FROM teacher");

echo "<table >
<tr>
<th>姓名</th>
<th>工号</th>
<th>密码</th>
</tr>";

while($row = mysql_fetch_array($result))
  {
  echo "<tr>";
  echo "<td>" . $row['tname'] . "</td>";
  echo "<td>" . $row['tid'] . "</td>";
  echo "<td>" . $row['tpassword'] . "</td>";
  echo "</tr>";
  }
echo "</table>";


?>
   
   </div>
   <div class="tab-pane fade" id="add_teacher" >
     <div class="container2" style=" padding-top:0px;">
       <div class="col-md-12">
    <form class="form-horizontal templatemo-create-account templatemo-container" role="form" action="insert_teacher.php" method="post">
	        <div class="form-inner">	
             <div class="form-group">
			            <div class="col-md-4">		          	
			            <label for="tname" class="control-label">老师姓名</label>
			            	<input type="text" class="form-control" name="tname" placeholder="">	
                           		            		            
			             </div>
                    </div>				 			        
			        <div class="form-group">
			          <div class="col-md-6">		          	
			            <label for="tid" class="control-label">老师工号</label>
			            <input type="text" class="form-control" name="tid" placeholder="">		            		            		            
			          </div>
                    </div>
                   
                     
			        <div class="form-group">
			          <div class="col-md-6">
			            <label for="tpassword" class="control-label">密码</label>
			            <input type="password" class="form-control" name="tpassword" placeholder="">
			          </div>
           	        </div>
                    <div class="form-group">
                      <div class="col-md-6">
			            <label for="password" class="control-label">确认密码</label>
			            <input type="password" class="form-control" name="password_confirm" placeholder="">
			          </div>
                    </div>			
                    <div class="form-group">
			           <div class="col-md-4">
			            <input type="submit" value="添加" name="submit" class="btn btn-info">
			          </div>
			        </div>	
		 </div>		
         		    	
     </form>	
   
  </div>
   </div>
   </div>

   <div class="tab-pane fade"  id="stu_information">
   <div style=" padding-left:150px;">
    
<?php
$result1 = mysql_query("SELECT * FROM stu");

echo "<table >
<tr>
<th>姓名</th>
<th>学号</th>
<th>密码</th>
</tr>";

while($row = mysql_fetch_array($result1))
  {
  echo "<tr>";
  echo "<td>" . $row['sname'] . "</td>";
  echo "<td>" . $row['sid'] . "</td>";
  echo "<td>" . $row['spassword'] . "</td>";
  echo "</tr>";
  }
echo "</table>";


?>
     </div>
   
   </div>
   <div class="tab-pane fade" id="lessons" style=" padding-left:150px;">
      
    <?php
$result2 = mysql_query("SELECT * FROM course");

echo "<table >
<tr>
<th>课程编号</th>
<th>课程名称</th>
<th>开课老师</th>
<th>学分</th>

</tr>";

while($row = mysql_fetch_array($result2))
  {
  echo "<tr>";
  echo "<td>" . $row['cid'] . "</td>";
  echo "<td>" . $row['cname'] . "</td>";
  echo "<td>" . $row['tname'] . "</td>";
  echo "<td>" . $row['cgrade'] . "</td>";
  echo "</tr>";
  }
echo "</table>";


?>
   
   </div>
   <div class="tab-pane fade" id="stu_lessons" style=" padding-left:150px;">
    <form class="form-inline" role="form" action="admin_workspace_for_search.php"method="post" >
  <div class="form-group" >
    
    <input type="text" name= "cid" class="form-control"style="width:300px ;height: 30px;font-size: 10px;" placeholder="输入要找的课程编号..">
  </div>
   <input type="submit" class="btn btn-info" value="搜索">
          
        </input>
 </form>

   </div>
   
   
   </div>
   </div>

<script>
   $(function () {
      $('#myTab li:eq(0) a').tab('show');
   });
</script>

</div>





</body>
</html>
