<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php
session_start();
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>myworkspace for teacher</title>
<style type="text/css"> 
table,td{ 
 border:1px solid #ccc; 
 line-height: 30px;
 border-collapse:collapse; 
 text-align: center;
} 
td{
  
  text-align: center;
  min-width: 100px;

}
th{
   border:1px solid #ccc; 
   text-align: center;
   padding-left,padding-right: 100px;
   
   
}
</style>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<link href="css/bootstrap-theme.min.css" rel="stylesheet" type="text/css">
	<link href="css/templatemo_style.css" rel="stylesheet" type="text/css">	
    <link href="http://libs.baidu.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet">
   <script src="http://libs.baidu.com/jquery/2.0.0/jquery.min.js"></script>
   <script src="http://libs.baidu.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
</head>

<body class="templatemo-bg-gray">
<?php
header("content-type:text/html;charset=utf-8");
//连接数据库

$dblink=mysql_connect("localhost","root","") or die("数据库连接失败");

//设置字符串编码

mysql_query("set names utf8");

//选择数据库

mysql_select_db("homework");
if(!$_SESSION['tid']||!$_SESSION['tname'])
{
  header("location:login1.html");
}
else
{
  $tid=$_SESSION['tid'];  
  $sql="select tname from teacher where tid='$tid'"; 
  $rs=mysql_query($sql); 
  $row=mysql_fetch_array($rs);
  $tname=$row['tname'];
  
}
?>

<div id="header1" ><img src="images/worksapce_logo.jpg"  alt="" /><?php echo $tname ;?>,欢迎你。
</div>
<div  style=" width:80%;text-align:right;" >
<div class="btn btn-default">
  <a href="sign_out1.php">注销</a>
  </div>

</div>
<div id="container4">
<div style="width:120px; float:left; background-color:#FFF; padding:0px;"  class="templatemo-container">
   <ul id="myTab" class="nav nav-pills  nav-stacked " style="width:100px;"> 
   <li ><a href="#home" data-toggle="tab"  style="width:120px;  ">开始课程</a></li>
   <li  ><a href="#ios" data-toggle="tab"style="width:120px;" >发布作业</a></li>
  
   <li><a href="#sold" data-toggle="tab" style="width:120px; ">批改作业</a></li>
   <li><a href="#sold1" data-toggle="tab" style="width:120px; ">我的课程</a></li>
   
   </ul>
</div>
<div style=" width:680 px;">
<div id="myTabContent" class="tab-content">

   <div class="tab-pane fade in active " style=" padding-left:150px;" id="home">
      
<?php
     
$result3 = mysql_query("SELECT * FROM course where tid='$tid'");

echo "<table >
<tr>

<th>我的课程</th>
<th>课程编号</th>
<th>作业次数</th>
<th>学分</th>
</tr>";

while($row = mysql_fetch_array($result3))
  {
  echo "<tr>";
  
  echo "<td>" . $row['cname'] . "</td>"; 
  echo "<td>" . $row['cid'] . "</td>";
  echo "<td>" . $row['times'] . "</td>";
  echo "<td>" . $row['cgrade'] . "</td>";
  echo "</tr>";
  }
echo "</table>";


?>
      
   
   </div>
   <div class="tab-pane fade" id="ios" style=" padding-left:150px;">
      
       <div class="col-md-12">			
			<form class="form-horizontal templatemo-create-account templatemo-container" role="form" action="insert_homework.php" method="post">
				<div class="form-inner">
					
			        <div class="form-group">
                <div class="col-md-3  ">                
                  <label for="cid" class="control-label">课程编号</label>
                  <input type="text" class="form-control" name="cid" placeholder="">                                             
                </div>              
              </div><div class="form-group">
                <div class="col-md-3  ">                
                  <label for="time" class="control-label">作业次数</label>
                  <input type="text" class="form-control" name="time" placeholder="">                                             
                </div>              
              </div>
                    <div class="form-group">
			          <div class="col-md-3  ">		          	
			            <label for="fullmark" class="control-label">作业总分</label>
			            <input type="text" class="form-control" name="fullmark" placeholder="">	            		            		            
			          </div>              
			        </div>
                    <div class="form-group">
			          <div class="col-md-6  ">		          	
			            <label for="deadline" class="control-label">截至日期</label>
			            <input type="date" class="form-control" name="deadline" placeholder="2015-X-X">	 
                             		            		            
			          </div>              
			        </div>
    
                     <div class="form-group">
			          <div class="col-md-8  ">		          	
			            <label for="request">具体要求</label>
			            <textarea class="form-control" name="request" rows="3" placeholder="尽量不要刁难学生。"></textarea>	            		            		            
			          </div>              
			        </div>	
                    	
			       
			        
			        
			        <div class="form-group">
			          <div class="col-md-12">
			            <input type="submit"  name="submit" value="上传" class="btn btn-info">
			            
			          </div>
			        </div>	
				</div>				    	
		      </form>		      
		

</div>
   </div>
   <div class="tab-pane fade" id="sold" style=" padding-left:150px;">
       
       <div class="col-md-12">
    <form class="form-horizontal templatemo-create-account templatemo-container" role="form" action="comments_homework.php" method="post">
        <div class="form-inner">
          
              <div class="form-group">
                <div class="col-md-3  ">                
                  <label for="hid" class="control-label">作业编号</label>
                  <input type="number" class="form-control" name="hid" placeholder="">                                             
                </div>              
              </div>
                    <div class="form-group">
                <div class="col-md-3  ">                
                  <label for="mark" class="control-label">作业得分</label>
                  <input type="text" class="form-control" name="mark" placeholder="">                                             
                </div>              
              </div>
                    
    
                     <div class="form-group">
                <div class="col-md-8  ">                
                  <label for="comments">评语</label>
                  <textarea class="form-control" name="comments" rows="3" placeholder="可为空。"></textarea>                                              
                </div>              
              </div>  
                      
             
              
              
              <div class="form-group">
                <div class="col-md-12">
                  <input type="submit"  name="submit" value="批改" class="btn btn-info">
                  
                </div>
              </div> 

        </div>              
          </form> 
        
              </div> 
   
   </div>
  
   <!--开设的课程 begin-->  
<div class="tab-pane fade" id="sold1" style=" padding-left:30px;float:right; width:680px; text-align:left; ">
      
    <ul id="myTab" class="nav nav-tabs  " >
  
   <li><a href="#stu_list" data-toggle="tab">我的学生</a></li>
   <li><a href="#homework_list" data-toggle="tab">我发布的作业</a></li>
   <li><a href="#grade" data-toggle="tab">成绩册</a></li>
   <li><a href="#modify" data-toggle="tab">修改截止日期</a></li>
   <li><a href="#stu_homework" data-toggle="tab">收到的作业</a></li>
  </ul>

   <div id="myTabContent" class="tab-content">   
      <div class="tab-pane fade" id="stu_list">
<?php
    
$con1=mysql_connect("localhost","root","");

$sql1 = "SELECT * FROM course where tid='$tid'";

$result4=mysql_query($sql1,$con1);

while($row = mysql_fetch_array($result4))
  {
    $cid1=$row['cid'];
    $con2=mysql_connect("localhost","root","");
    $sql2="SELECT * FROM sc where  cid='$cid1'"; 
    $result5=mysql_query($sql2,$con2);
    echo "<table >
<tr>

<th>我的课程</th>
<th>学生姓名</th>
<th>学生学号</th>

</tr>";
while($row1 = mysql_fetch_array($result5))
{
  echo "<tr>";
  
  echo "<td>" . $row1['cname'] . "</td>"; 
  echo "<td>" . $row1['sname'] . "</td>";
  echo "<td>" . $row1['sid'] . "</td>";
 
  echo "</tr>";
  }

  echo "</table>";
  echo "</br>";
  }



?>
      </div>
      <div class="tab-pane fade" id="homework_list" style=" margin-top:10px;">
      
<?php
     
$result6 = mysql_query( "SELECT * FROM homework where tid='$tid' and sid='$tid' ");
$change="";
echo "<table >
<tr>
<th>课程编号</th>
<th>第几次作业</th>
<th>总分</th>
<th>作业要求</th>
<th>截止日期</th>

</tr>";

while($row = mysql_fetch_array($result6))
  {
  echo "<tr>";
  echo "<td>" . $row['cid'] . "</td>";
  echo "<td>" . $row['time'] . "</td>"; 
  echo "<td>" . $row['fullmark'] . "</td>";
  echo "<td>" . $row['request'] . "</td>";
  echo "<td>" . $row['deadline'] . "</td>";

  echo "</tr>";

  }
echo "</table>";


?>
      </div>
      <div class="tab-pane fade" id="grade">
<?php
     
$result6 = mysql_query( "SELECT * FROM homework where tid='$tid' and sid!='$tid' ");

echo "<table >
<tr>
<th>课程编号</th>
<th>第几次作业</th>
<th>总分</th>
<th>作业要求</th>
<th>截止日期</th>

</tr>";

while($row = mysql_fetch_array($result6))
  {
  echo "<tr>";
  echo "<td>" . $row['cid'] . "</td>";
  echo "<td>" . $row['time'] . "</td>"; 
  echo "<td>" . $row['fullmark'] . "</td>";
  echo "<td>" . $row['request'] . "</td>";
  echo "<td>" . $row['deadline'] . "</td>";

  echo "</tr>";
  }
echo "</table>";


?>
      </div>
      <div class="tab-pane fade" id="modify">

       <form class="form-horizontal templatemo-create-account templatemo-container" role="form" action="modify_homework.php" method="post">
        <div class="form-inner">
          
              <div class="form-group">
                <div class="col-md-3  ">                
                  <label for="cid" class="control-label">课程编号</label>
                  <input type="text" class="form-control" name="cid" placeholder="">                                             
                </div>              
              </div><div class="form-group">
                <div class="col-md-3  ">                
                  <label for="time" class="control-label">作业次数</label>
                  <input type="text" class="form-control" name="time" placeholder="">                                             
                </div>              
              </div>
                    
                    <div class="form-group">
                <div class="col-md-6  ">                
                  <label for="deadline" class="control-label">更改截至日期</label>
                  <input type="date" class="form-control" name="deadline" placeholder="2015-X-X">  
                                                            
                </div>              
              </div>
    
          <div class="form-group">
                <div class="col-md-12">
                  <input type="submit"  name="submit" value="上传" class="btn btn-info">
                  
                </div>
              </div>  
        </div>              
          </form> 
      </div>
      <div class="tab-pane fade" id="stu_homework" style=" margin-top:10px;">
<?php
     
$result7 = mysql_query( "SELECT * FROM homework where tid='$tid' and sid!='$tid' ORDER BY  time");

echo "<table >
<tr>
<th>课程编号</th>
<th>第几次作业</th>
<th>作业总分</th>
<th>作业编号</th>
<th>作业文本连接</th>
<th>作业得分</th>
<th>评语</th>
</tr>";

while($row = mysql_fetch_array($result7))
  {
  echo "<tr>";
  echo "<td>" . $row['cid'] . "</td>";
  echo "<td>" . $row['time'] . "</td>"; 
  echo "<td>" . $row['fullmark'] . "</td>";
  echo "<td>" . $row['hid'] . "</td>";
  echo "<td>" . $row['file'] . "</td>";
  echo "<td>" . $row['mark'] . "</td>";
  echo "<td>" . $row['comments'] . "</td>";
  echo "</tr>";
  }
echo "</table>";


?>

      </div>
   </div>
</div>
<!--开设的课程 end--> 
   <div class="tab-pane fade" id="sold2" style=" padding-left:150px;">
      
    <p>这里要用php3</p>
   
   </div>
   
   </div>
   </div>
    </div>

<script>
   $(function () {
      $('#myTab li:eq(0) a').tab('show');
   });
</script>

</div>





</body>
</html>
