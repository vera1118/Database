<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php session_start(); ?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<body style="text-align:center; font-size:50px; font:'微软雅黑';">

<?php
header("content-type:text/html;charset=utf-8");
//连接数据库

$dblink=mysql_connect("localhost","root","") or die("数据库连接失败");

//设置字符串编码

mysql_query("set names utf8");

//选择数据库

mysql_select_db("homework");

//获取表单数据。
$sid=$_POST['sid'];
$spassword=$_POST['spassword'];

$sql="select * from stu where sid='$sid'";  

$rs=mysql_query($sql); //执行sql查询

$num=mysql_num_rows($rs); //获取记录数

if($num)
{ // 用户存在；
   $row=mysql_fetch_array($rs);
   if($spassword==$row['spassword'])
   { //对密码进行判断。
    echo "登陆成功，正在为你跳转至后台页面";
    $_SESSION['sname']=$row['sname'];
    $_SESSION['sid']=$row['sid'];
    header("location:myworkspace.php");

    }
    else{
        echo "密码不正确";
        
    } 

}
else{

 

 echo "用户不存在";

 echo '<a href:login.html>返回登陆页面</a>';


}

?>
</body>
</html>