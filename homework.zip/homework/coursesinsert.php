<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php session_start(); ?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<body>
<?php
header("content-type:text/html;charset=utf-8");
if(!isset($_POST['submit'])){
    exit('非法访问!');
}
$cid = $tname = $tpassword = $password_confirm = "";
$cid = $_POST['cid'];
$sid=$_SESSION['sid'];

$con=mysql_connect("localhost","root","") or die("数据库连接失败");
mysql_query($con,"set names utf8");
mysql_select_db("homework", $con);
$check_query = mysql_query("select * from sc where cid='$cid' and sid='$sid'");

if(mysql_fetch_array($check_query))
{
	
    echo '此课程已添加<a href="javascript:history.back(-1);">返回</a>';
    exit;
}

$regdate = time();
$result3 = mysql_query("SELECT * FROM course where cid='$cid'");
$row = mysql_fetch_array($result3);

$result4 = mysql_query("SELECT * FROM stu where sid='$sid'");
$row1 = mysql_fetch_array($result4);
$sname=$row1['sname'];
$cname=$row['cname'];
$tname=$row['tname'];
$cid=$row['cid'];
$cgrade=$row['cgrade'];
$sql ="INSERT INTO sc (sid,sname,cname,tname,cid,cgrade)VALUES( '$sid','$sname','$cname','$tname','$cid','$cgrade')";
if(mysql_query($sql,$con))
{
    header("Location:course_insert_success.html");
} 
else 
{
    echo '抱歉！添加数据失败：',mysql_error(),'<br />';
    echo '点击此处 <a href="javascript:history.back(-1);">返回</a> 重试';
}
?>
</body>
</html>