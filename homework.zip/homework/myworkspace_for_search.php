<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php
session_start();
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>myworkspace for student</title>
<style type="text/css"> 
table,td{ 
 border:1px solid #ccc; 
 line-height: 30px;
 border-collapse:collapse; 
 text-align: center;
} 
td{
  width: 100px;
  text-align: center;

}
th{
   border:1px solid #ccc; 
   text-align: center;
   padding-left,padding-right: 100px;
   
   
}
</style>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<link href="css/bootstrap-theme.min.css" rel="stylesheet" type="text/css">
	<link href="css/templatemo_style.css" rel="stylesheet" type="text/css">	
    <link href="http://libs.baidu.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet">
   <script src="http://libs.baidu.com/jquery/2.0.0/jquery.min.js"></script>
   <script src="http://libs.baidu.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
</head>

<body class="templatemo-bg-gray">
<?php
header("content-type:text/html;charset=utf-8");
//连接数据库

$dblink=mysql_connect("localhost","root","") or die("数据库连接失败");

//设置字符串编码

mysql_query("set names utf8");

//选择数据库

mysql_select_db("homework");
if(!$_SESSION['sid']||!$_SESSION['sname'])
{
  header("location:login.html");
}
else
{
  $sid=$_SESSION['sid'];  
  $sql="select sname from stu where sid='$sid'"; 
  $rs=mysql_query($sql); 
  $row=mysql_fetch_array($rs);
  $sname=$row['sname'];
  
}
?>

<div id="header1" ><img src="images/worksapce_logo.jpg"  alt="" /><?php echo $sname ;?>,欢迎你。
</div>
<div  style=" width:80%;text-align:right;" >
<div class="btn btn-default">
  <a href="sign_out.php">注销</a>
  </div>

</div>
<div id="container4">
<div style="width:120px; float:left; background-color:#FFF; padding:0px;"  class="templatemo-container">
<ul id="myTab" class="nav nav-pills  nav-stacked " style="width:100px;"> 
<li ><a href="#home" data-toggle="tab"  style="width:120px;  ">我的课程</a></li>
<li><a href="#noinsert" data-toggle="tab" style="width:120px; ">未加入的课程</a></li>
   <li  ><a href="#ios" data-toggle="tab"style="width:120px;" >加入课程</a></li>
  
   <li><a href="#sold" data-toggle="tab" style="width:120px; ">查看作业</a></li>
   <li><a href="#uploading" data-toggle="tab" style="width:120px; ">提交作业</a></li>
   
   
   
</ul>
</div>
<div id="myTabContent" class="tab-content">

   <div class="tab-pane fade in active "  id="home">
   <div style=" padding-left:150px;">
     
<?php
     
$result3 = mysql_query("SELECT * FROM sc where sid='$sid'");

echo "<table >
<tr>

<th>我的课程</th>
<th>课程编号</th>
<th>开课老师</th>
<th>学分</th>
</tr>";

while($row = mysql_fetch_array($result3))
  {
  echo "<tr>";
  
  echo "<td>" . $row['cname'] . "</td>"; 
  echo "<td>" . $row['cid'] . "</td>";
  echo "<td>" . $row['tname'] . "</td>";
  echo "<td>" . $row['cgrade'] . "</td>";
  echo "</tr>";
  }
echo "</table>";


?>
     </div>
   
   </div>
   <div class="tab-pane fade" id="noinsert" style=" padding-left:150px;">
      
    <?php
     
$result6 = mysql_query("SELECT cid FROM sc where sid='$sid'");
$row1 = mysql_fetch_array($result6);

$result7 = mysql_query("SELECT * FROM course ");
echo "<table >
<tr>


<th>课程编号</th>
<th>课程名称</th>
<th>开课老师</th>
<th>学分</th>
</tr>";

while($row = mysql_fetch_array($result7))
  {
    $check=$row['cid'];
    $result8=mysql_query("SELECT cid FROM sc where sid='$sid'and cid='$check'");
  if (!mysql_fetch_array($result8)) {
  echo "<tr>";
  echo "<td>" . $row['cid'] . "</td>";
  echo "<td>" . $row['cname'] . "</td>";
  echo "<td>" . $row['tname'] . "</td>";
  echo "<td>" . $row['cgrade'] . "</td>";
  echo "</tr>";
    # code...
  }
  
  }
echo "</table>";


?>
   
   </div>
   <div class="tab-pane fade" id="ios" style=" padding-left:150px;">

    <form class="form-inline" role="form" action="myworkspace_for_search.php" method="post">
  <div class="form-group" >
    
    <input type="text" name ="cid" class="form-control"style="width:300px ;height: 30px;font-size: 10px;" placeholder="输入所要加入的课程编号...">
  </div>
   <input type="submit" name="submit" class="btn btn-info" value="加入">
          
        </input>
 </form>
      
   </div>
   <div class="tab-pane fade" id="sold" style=" padding-left:150px;">
      
    <form class="form-inline" role="form" action="coursesinsert.php" method="post">
  <div class="form-group" >
    
    <input type="text" name ="cid" class="form-control"style="width:300px ;height: 30px;font-size: 10px;" placeholder="搜索所在的课程编号...">
  </div>
   <input type="submit" name="submit" class="btn btn-info" value="搜索">
          
        </input>
 </form>
<?php
     $cid="";
     $cid=$_POST['cid'];
$result3 = mysql_query("SELECT * FROM homework where cid='$cid'and sid=tid ORDER BY time");

echo "<table >
<tr>
<th>课程编号</th>
<th>第几次作业</th>
<th>总分</th>
<th>作业要求</th>
<th>截止日期</th>

</tr>";

while($row = mysql_fetch_array($result3))
  {
  echo "<tr>";
  echo "<td>" . $row['cid'] . "</td>";
  echo "<td>" . $row['time'] . "</td>"; 
  echo "<td>" . $row['fullmark'] . "</td>";
  echo "<td>" . $row['request'] . "</td>";
  echo "<td>" . $row['deadline'] . "</td>";

  echo "</tr>";

  }
echo "</table>";


?>
   
   </div>
    <div class="tab-pane fade" id="uploading" style=" padding-left:150px;">
     <div class="col-md-12">      
      <form class="form-horizontal templatemo-create-account templatemo-container" role="form" action="homework_uploading.php" method="post">
        <div class="form-inner">
          
              <div class="form-group">
                <div class="col-md-3  ">                
                  <label for="cid" class="control-label">课程编号</label>
                  <input type="text" class="form-control" name="cid" placeholder="">                                             
                </div>              
              </div>
              <div class="form-group">
                <div class="col-md-3  ">                
                  <label for="time" class="control-label">第几次作业</label>
                  <input type="text" class="form-control" name="time" placeholder="">                                             
                </div>              
              </div>

             <div class="form-group">
                <div class="col-md-8  ">                
                  <label for="file">提交文本</label>
                  <textarea class="form-control" name="file" rows="3" placeholder=""></textarea>                                              
                </div>              
              </div>  

              <div class="form-group">
                <div class="col-md-12">
                  <input type="submit"  name="submit" value="上传" class="btn btn-info">
                  
                </div>
              </div>  
        </div>              
          </form>    
    </div>
   </div>
   </div>
   </div>

<script>
   $(function () {
      $('#myTab li:eq(3) a').tab('show');
   });
</script>

</div>





</body>
</html>
